extends Sprite2D
@export var look_at_me_I_exported_a_var = "test"


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_pressed("color_change") == true:
		modulate = Color(1, 0, 0)
		print(look_at_me_I_exported_a_var)
	else:
		modulate = Color(0, 1, 0)
		
